The file named BST implements the methods of a binary search tree which are: insert, delete, find, inOrder (traversal), preOrder (traversal),
postOrder (traversal) and printBST

The file named BSTtest is used to test the methods implemented in BST class by reading the commands from a text file.