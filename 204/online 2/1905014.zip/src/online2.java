import java.util.Scanner;

public class online2 {

        
}

